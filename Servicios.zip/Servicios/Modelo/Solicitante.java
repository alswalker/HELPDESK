package Modelo;

public class Solicitante {

    private String NOMBRES, IDENTIFICACION, CORREO;
    private int ID_SOLICITANTE, ID_USUARIO, ID_EMPRESA;

    /*-----CONSTRUCT-------*/
    public Solicitante(String NOMBRES, String IDENTIFICACION, String CORREO, int ID_SOLICITANTE, int ID_USUARIO, int ID_EMPRESA) {
        this.NOMBRES = NOMBRES;
        this.IDENTIFICACION = IDENTIFICACION;
        this.CORREO = CORREO;
        this.ID_USUARIO = ID_USUARIO;
        this.ID_EMPRESA = ID_EMPRESA;
        this.ID_SOLICITANTE = ID_SOLICITANTE;
    }

    /*-----GETTER & SETTER------*/
    public String getNOMBRES() {
        return NOMBRES;
    }

    public void setNOMBRES(String NOMBRES) {
        this.NOMBRES = NOMBRES;
    }

    public String getIDENTIFICACION() {
        return IDENTIFICACION;
    }

    public void setIDENTIFICACION(String IDENTIFICACION) {
        this.IDENTIFICACION = IDENTIFICACION;
    }

    public String getCORREO() {
        return CORREO;
    }

    public void setCORREO(String CORREO) {
        this.CORREO = CORREO;
    }

    public int getID_SOLICITANTE() {
        return ID_SOLICITANTE;
    }

    public void setID_SOLICITANTE(int ID_SOLICITANTE) {
        this.ID_SOLICITANTE = ID_SOLICITANTE;
    }

    public int getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(int ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }

    public int getID_EMPRESA() {
        return ID_EMPRESA;
    }

    public void setID_EMPRESA(int ID_EMPRESA) {
        this.ID_EMPRESA = ID_EMPRESA;
    }
}