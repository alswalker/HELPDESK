package Modelo;

public class Autenticar {
    
    private String USUARIO, NOMBRES;
    private int ID_USUARIO, ID_EMPLEADO;

    public Autenticar(int ID_USUARIO, int ID_EMPLEADO, String USUARIO, String NOMBRES) {
        this.ID_USUARIO = ID_USUARIO;
        this.ID_EMPLEADO = ID_EMPLEADO;
        this.USUARIO = USUARIO;
        this.NOMBRES = NOMBRES;
    }

    public String getUSUARIO() {
        return USUARIO;
    }

    public void setUSUARIO(String USUARIO) {
        this.USUARIO = USUARIO;
    }

    public String getNOMBRES() {
        return NOMBRES;
    }

    public void setNOMBRES(String NOMBRES) {
        this.NOMBRES = NOMBRES;
    }

    public int getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(int ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }

    public int getID_EMPLEADO() {
        return ID_EMPLEADO;
    }

    public void setID_EMPLEADO(int ID_EMPLEADO) {
        this.ID_EMPLEADO = ID_EMPLEADO;
    }    
}