package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csSolicitante {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csSolicitante() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertarSolicitante(String NOMBRES, String IDENTIFICACION, String CORREO, int ID_USUARIO, int ID_EMPRESA) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_SOLICITANTE (ID_USUARIO, ID_EMPRESA, NOMBRES, IDENTIFICACION, CORREO)"
                    + "VALUES (" + ID_USUARIO + ", "
                    + "        " + ID_EMPRESA + ", "
                    + "       '" + NOMBRES + "',"
                    + "       '" + IDENTIFICACION + "',"
                    + "       '" + CORREO + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizarSolicitante(int ID_SOLICITANTE, int ID_USUARIO, int ID_EMPRESA, String NOMBRES, String IDENTIFICACION, String CORREO) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_SOLICITANTE SET "
                    + "ID_USUARIO = " + ID_USUARIO + ","
                    + "ID_EMPRESA = " + ID_EMPRESA + ", "
                    + "NOMBRES = '" + NOMBRES + "',"
                    + "IDENTIFICACION = '" + IDENTIFICACION + "',"
                    + "CORREO = '" + CORREO + "',"
                    + "WHERE ID_SOLICITANTE = " + ID_SOLICITANTE + ""); //CON ENTEROS NO SE UTILIZAN ''
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminarSolicitante(int ID_SOLICITANTE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_SOLICITANTE WHERE ID_SOLICITANTE = " + ID_SOLICITANTE + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Solicitante> listarSolicitante() {
        Solicitante s = null;
        ArrayList<Solicitante> lista = new ArrayList<Solicitante>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOLICITANTE");

            while (rs.next()) {
                s = new Solicitante(rs.getString("NOMBRES"),
                                    rs.getString("IDENTIFICACION"), rs.getString("CORREO"),
                                    rs.getInt(1), rs.getInt(2), rs.getInt(3));
                lista.add(s);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Solicitante listarSolicitantePorID(int ID_SOLICITANTE) {
        Solicitante u = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOLICITANTE WHERE ID_SOLICITANTE= " + ID_SOLICITANTE + "");

            while (rs.next()) {
                u = new Solicitante(rs.getString("NOMBRES"),
                                    rs.getString("IDENTIFICACION"), rs.getString("CORREO"),
                                    rs.getInt(1), rs.getInt(2), rs.getInt(3));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return u;
    }
}
