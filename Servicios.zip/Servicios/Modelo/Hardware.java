package Modelo;

public class Hardware {

    private String TIPO_HARDWARE;
    private int ID_HARDWARE;

    /*-----CONSTRUCT-------*/
    public Hardware(String TIPO_HARDWARE, int ID_HARDWARE) {
        this.ID_HARDWARE = ID_HARDWARE;
        this.TIPO_HARDWARE = TIPO_HARDWARE;
    }

    /*-----GETTER & SETTER------*/
    public String getTIPO_HARDWARE() {
        return TIPO_HARDWARE;
    }

    public void setTIPO_HARDWARE(String TIPO_HARDWARE) {
        this.TIPO_HARDWARE = TIPO_HARDWARE;
    }

    public int getID_HARDWARE() {
        return ID_HARDWARE;
    }

    public void setID_HARDWARE(int ID_HARDWARE) {
        this.ID_HARDWARE = ID_HARDWARE;
    }
}