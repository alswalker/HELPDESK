package Modelo;

public class AtencionIncidencia {

    private String FECHA_ATENCION_IN, OBSERVACIONES, ESTADO;
    private int ID_INCIDENCIA, ID_SOLICITANTE, ID_EMPLEADO, ID_ATENCION_IN;

    public AtencionIncidencia(String FECHA_ATENCION_IN, String OBSERVACIONES, String ESTADO, int ID_INCIDENCIA, int ID_SOLICITANTE, int ID_EMPLEADO, int ID_ATENCION_IN) {
        this.ID_ATENCION_IN = ID_ATENCION_IN;
        this.FECHA_ATENCION_IN = FECHA_ATENCION_IN;
        this.OBSERVACIONES = OBSERVACIONES;
        this.ESTADO = ESTADO;
        this.ID_INCIDENCIA = ID_INCIDENCIA;
        this.ID_SOLICITANTE = ID_SOLICITANTE;
        this.ID_EMPLEADO = ID_EMPLEADO;
    }

    public String getFECHA_ATENCION_IN() {
        return FECHA_ATENCION_IN;
    }

    public String getOBSERVACIONES() {
        return OBSERVACIONES;
    }

    public String getESTADO() {
        return ESTADO;
    }

    public int getID_INCIDENCIA() {
        return ID_INCIDENCIA;
    }

    public int getID_SOLICITANTE() {
        return ID_SOLICITANTE;
    }

    public int getID_EMPLEADO() {
        return ID_EMPLEADO;
    }

    public int getID_ATENCION_IN() {
        return ID_ATENCION_IN;
    }

    public void setFECHA_ATENCION_IN(String FECHA_ATENCION_IN) {
        this.FECHA_ATENCION_IN = FECHA_ATENCION_IN;
    }

    public void setOBSERVACIONES(String OBSERVACIONES) {
        this.OBSERVACIONES = OBSERVACIONES;
    }

    public void setESTADO(String ESTADO) {
        this.ESTADO = ESTADO;
    }

    public void setID_INCIDENCIA(int ID_INCIDENCIA) {
        this.ID_INCIDENCIA = ID_INCIDENCIA;
    }

    public void setID_SOLICITANTE(int ID_SOLICITANTE) {
        this.ID_SOLICITANTE = ID_SOLICITANTE;
    }

    public void setID_EMPLEADO(int ID_EMPLEADO) {
        this.ID_EMPLEADO = ID_EMPLEADO;
    }

    public void setID_ATENCION_IN(int ID_ATENCION_IN) {
        this.ID_ATENCION_IN = ID_ATENCION_IN;
    }
}