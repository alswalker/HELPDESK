package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csAtencionIncidencia {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csAtencionIncidencia() {
        this.con = null;
        this.stm = null;
    }

    //insertar
    public int insertarAtencionIncidencia(int ID_INCIDENCIA, int ID_SOLICITANTE, int ID_EMPLEADO, String FECHA_ATENCION_IN, String OBSERVACIONES, String ESTADO) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();

            respuesta = stm.executeUpdate("INSERT INTO dbo.T_ATENCION_INCIDENCIA (ID_INCIDENCIA,ID_SOLICITANTE,ID_EMPLEADO,FECHA_ATENCION_IN,OBSERVACIONES,ESTADO) "
                    + "VALUES (" + ID_INCIDENCIA + ", "
                    + "" + ID_SOLICITANTE + ", "
                    + "" + ID_EMPLEADO + ","
                    + "'" + FECHA_ATENCION_IN + "',"
                    + "'" + OBSERVACIONES + "', "
                    + "'" + ESTADO + "')");

            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    //ACTUALIZAR
    public int actualizarAtencionIncidencia(int ID_INCIDENCIA, int ID_SOLICITANTE, int ID_EMPLEADO, String FECHA_ATENCION_IN, String OBSERVACIONES, String ESTADO, int ID_ATENCION_IN) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_ATENCION_INCIDENCIA SET "
                    + "ID_INCIDENCIA = " + ID_INCIDENCIA + ","
                    + "ID_SOLICITANTE = " + ID_SOLICITANTE + ","
                    + "ID_EMPLEADO = " + ID_EMPLEADO + ","
                    + "FECHA_ATENCION_IN = '" + FECHA_ATENCION_IN + "',"
                    + "OBSERVACIONES = '" + OBSERVACIONES + "',"
                    + "ESTADO = '" + ESTADO + "'"
                    + "WHERE ID_ATENCION_IN = " + ID_ATENCION_IN + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    //ELIMINAR
    public int eliminarAtencionIncidencia(int ID_ATENCION_IN) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_ATENCION_INCIDENCIA WHERE ID_ATENCION_IN = " + ID_ATENCION_IN + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    //LISTA
    public ArrayList<AtencionIncidencia> listarAtencionIncidencia() {
        AtencionIncidencia a = null;
        ArrayList<AtencionIncidencia> lista = new ArrayList<AtencionIncidencia>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_ATENCION_INCIDENCIA");

            while (rs.next()) {
                a = new AtencionIncidencia(rs.getString("FECHA_ATENCION_IN"), rs.getString("OBSERVACIONES"), rs.getString("ESTADO"),
                                           rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4));
                lista.add(a);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    public AtencionIncidencia listarAtencionIncidenciaPorID(int ID_ATENCION_IN) {
        AtencionIncidencia a = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_ATENCION_INCIDENCIA WHERE ID_ATENCION_IN= " + ID_ATENCION_IN + " ");

            while (rs.next()) {
                a = new AtencionIncidencia(rs.getString("FECHA_ATENCION_IN"), rs.getString("OBSERVACIONES"), rs.getString("ESTADO"),
                        rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4));

            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return a;
    }
}