package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csIncidencia {

    private Connection con; //open, close of database
    private Statement stm; //insert, delete, update and select
    private ResultSet rs; //data container.

    public csIncidencia() {
        this.con = null;
        this.stm = null;
    }

    public int insertarIncidencia(int ID_HARDWARE, int ID_SOFTWARE, String FECHA_INCIDENCIA, String ESTADO) {
        int respuesta = 0;
        //instancia de la clase conexion
        csConexion c1 = new csConexion();
        con = c1.conectar();
        try {

            stm = con.createStatement();
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_INCIDENCIA (ID_HARDWARE, ID_SOFTWARE, FECHA_INCIDENCIA, ESTADO) "
                    + "VALUES (" + ID_HARDWARE + ", "
                    + "" + ID_SOFTWARE + ", "
                    + "'" + FECHA_INCIDENCIA + "', "
                    + "'" + ESTADO + "')");
            c1.desconectar();
            con.close();
            stm.close();

        } catch (Exception ex) {
        }
        return respuesta;
    }

    public int actualizarIncidencia(int ID_HARDWARE, int ID_SOFTWARE, String FECHA_INCIDENCIA, String ESTADO, int ID_INCIDENCIA) {
        int respuesta = 0;
        csConexion c1 = new csConexion();
        con = c1.conectar();

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_INCIDENCIA SET "
                    + "" + "ID_HARDWARE= " + ID_HARDWARE + " ,"
                    + "" + "ID_SOFTWARE = " + ID_SOFTWARE + ", "
                    + "" + "FECHA_INCIDENCIA='" + FECHA_INCIDENCIA + "', "
                    + "" + " ESTADO='" + ESTADO + "' "
                    + "WHERE ID_INCIDENCIA=" + ID_INCIDENCIA + " ");
            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return respuesta;
    }

    public int eliminarIncidencia(int ID_INCIDENCIA) {
        int respuesta = 0;
        csConexion c1 = new csConexion();
        con = c1.conectar();

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_INCIDENCIA WHERE ID_INCIDENCIA=" + ID_INCIDENCIA + " ");
            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return respuesta;
    }

    public ArrayList<Incidencia> listarIncidencia() {
        Incidencia e = null;
        ArrayList<Incidencia> lista = new ArrayList<Incidencia>();
        //lista=null;

        csConexion c1 = new csConexion();
        con = c1.conectar();
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_INCIDENCIA");
            while (rs.next()) {
                e = new Incidencia(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString("FECHA_INCIDENCIA"), rs.getString("ESTADO"));
                lista.add(e);
            }

            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return lista;
    }

    public Incidencia listarIncidenciaPorID(int ID_INCIDENCIA) {
        Incidencia e = null;

        csConexion c1 = new csConexion();
        con = c1.conectar();
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_INCIDENCIA WHERE ID_INCIDENCIA=" + ID_INCIDENCIA + " ");
            while (rs.next()) {
                e = new Incidencia(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString("FECHA_INCIDENCIA"), rs.getString("ESTADO"));
            }

            c1.desconectar();
            con.close();
            stm.close();
        } catch (Exception ex) {

        }
        return e;
    }
}