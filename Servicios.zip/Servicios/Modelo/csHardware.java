package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csHardware {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csHardware() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertarHardware(String TIPO_HARDWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_HARDWARE (TIPO_HARDWARE)"
                    + "VALUES ('" + TIPO_HARDWARE + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizarHardware(String TIPO_HARDWARE, int ID_HARDWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_HARDWARE SET "
                    + "TIPO_HARDWARE = '" + TIPO_HARDWARE + "'"
                    + "WHERE ID_HARDWARE = " + ID_HARDWARE + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminarHardware(int ID_HARDWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_HARDWARE WHERE ID_HARDWARE = " + ID_HARDWARE + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Hardware> listarHardware() {
        Hardware h = null;
        ArrayList<Hardware> lista = new ArrayList<Hardware>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_HARDWARE");

            while (rs.next()) {
                        h = new Hardware(rs.getString("TIPO_HARDWARE"), rs.getInt(1));
                lista.add(h);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Hardware listarHardwarePorID(int ID_HARDWARE) {
        Hardware h = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_HARDWARE WHERE ID_HARDWARE= " + ID_HARDWARE + "");

            while (rs.next()) {
                h = new Hardware(rs.getString("TIPO_HARDWARE"), rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return h;
    }
}
