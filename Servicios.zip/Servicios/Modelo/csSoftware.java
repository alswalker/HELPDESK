package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csSoftware {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csSoftware() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertarSoftware(String TIPO_SOFTWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_SOFTWARE (TIPO_SOFTWARE) "
                    + "VALUES ('" + TIPO_SOFTWARE + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizarSoftware(String TIPO_SOFTWARE, int ID_SOFTWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_SOFTWARE SET "
                    + "TIPO_SOFTWARE = '" + TIPO_SOFTWARE + "' "
                    + "WHERE ID_SOFTWARE = " + ID_SOFTWARE + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminarSoftware(int ID_SOFTWARE) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_SOFTWARE WHERE ID_SOFTWARE = " + ID_SOFTWARE + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Software> listarSoftware() {
        Software s = null;
        ArrayList<Software> lista = new ArrayList<Software>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOFTWARE");

            while (rs.next()) {
                s = new Software(rs.getString("TIPO_SOFTWARE"), rs.getInt(1));
                lista.add(s);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Software listarSoftwarePorID(int ID_SOFTWARE) {
        Software s = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_SOFTWARE wHERE ID_SOFTWARE= " + ID_SOFTWARE + "");

            while (rs.next()) {
                s = new Software(rs.getString("TIPO_SOFTWARE"), rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return s;
    }
}