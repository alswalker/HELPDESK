package Modelo;

public class Incidencia {

    private int ID_INCIDENCIA, ID_HARDWARE, ID_SOFTWARE;
    private String FECHA_INCIDENCIA, ESTADO;

    public Incidencia(int ID_INCIDENCIA, int ID_HARDWARE, int ID_SOFTWARE, String FECHA_INCIDENCIA, String ESTADO) {
        this.ID_INCIDENCIA = ID_INCIDENCIA;
        this.ID_HARDWARE = ID_HARDWARE;
        this.ID_SOFTWARE = ID_SOFTWARE;
        this.FECHA_INCIDENCIA = FECHA_INCIDENCIA;
        this.ESTADO = ESTADO;
    }

    public int getID_INCIDENCIA() {
        return ID_INCIDENCIA;
    }

    public void setID_INCIDENCIA(int ID_INCIDENCIA) {
        this.ID_INCIDENCIA = ID_INCIDENCIA;
    }

    public int getID_HARDWARE() {
        return ID_HARDWARE;
    }

    public void setID_HARDWARE(int ID_HARDWARE) {
        this.ID_HARDWARE = ID_HARDWARE;
    }

    public int getID_SOFTWARE() {
        return ID_SOFTWARE;
    }

    public void setID_SOFTWARE(int ID_SOFTWARE) {
        this.ID_SOFTWARE = ID_SOFTWARE;
    }

    public String getFECHA_INCIDENCIA() {
        return FECHA_INCIDENCIA;
    }

    public void setFECHA_INCIDENCIA(String FECHA_INCIDENCIA) {
        this.FECHA_INCIDENCIA = FECHA_INCIDENCIA;
    }

    public String getESTADO() {
        return ESTADO;
    }

    public void setESTADO(String ESTADO) {
        this.ESTADO = ESTADO;
    }
}
