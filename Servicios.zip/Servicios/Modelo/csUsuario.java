package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class csUsuario {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csUsuario() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------INSERT----------------------*/
    public int insertarUsuario(String USUARIO, String CONTRASEÑA) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            /*NOTA: AL MENCIONAR NOMBRE DE LA TABLA ANTEPONER 'dbo' ANTES*/
            respuesta = stm.executeUpdate("INSERT INTO dbo.T_USUARIO (USUARIO,CONTRASEÑA) "
                    + "VALUES ('" + USUARIO + "','" + CONTRASEÑA + "')");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------UPDATE----------------------*/
    public int actualizarUsuario(String USUARIO, String CONTRASEÑA, int ID_USUARIO) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("UPDATE dbo.T_USUARIO SET "
                    + "USUARIO = '" + USUARIO + "',"
                    + "CONTRASEÑA = '" + CONTRASEÑA + "'" //ANTES DEL WHERE NO SE UTILIZA ','
                    + "WHERE ID_USUARIO = " + ID_USUARIO + ""); //CON ENTEROS NO SE UTILIZAN ''
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------DELETE----------------------*/
    public int eliminarUsuario(int ID_USUARIO) {
        int respuesta = 0;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB

        try {
            stm = con.createStatement();
            respuesta = stm.executeUpdate("DELETE FROM dbo.T_USUARIO WHERE ID_USUARIO = " + ID_USUARIO + "");
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            return 0;
        }
        return respuesta;
    }

    /*----------------------LIST----------------------*/
    public ArrayList<Usuario> listarUsuario() {
        Usuario u = null;
        ArrayList<Usuario> lista = new ArrayList<Usuario>();

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_USUARIO");

            while (rs.next()) {
                u = new Usuario(rs.getString("USUARIO"), rs.getString("CONTRASEÑA"), rs.getInt(1));
                lista.add(u);
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return lista;
    }

    /*--------------------LIST BY ID--------------------*/
    public Usuario listarUsuarioPorID(int ID_USUARIO) {
        Usuario u = null;

        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try {
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM dbo.T_USUARIO WHERE ID_USUARIO= '" + ID_USUARIO + "'");

            while (rs.next()) {
                u = new Usuario(rs.getString("USUARIO"), rs.getString("CONTRASEÑA"), rs.getInt(1));
            }
            c1.desconectar(); //Desconectar DB
            con.close();
            stm.close();
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
        return u;
    }
}