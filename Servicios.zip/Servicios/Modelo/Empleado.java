package Modelo;

public class Empleado {

    private int ID_EMPLEADO, ID_USUARIO;
    private String NOMBRES, IDENTIFICACION, CORREO, PUESTO;

    public Empleado(int ID_EMPLEADO, int ID_USUARIO, String NOMBRES, String IDENTIFICACION, String CORREO, String PUESTO) {
        this.ID_USUARIO = ID_USUARIO;
        this.ID_EMPLEADO = ID_EMPLEADO;
        this.NOMBRES = NOMBRES;
        this.IDENTIFICACION = IDENTIFICACION;
        this.CORREO = CORREO;
        this.PUESTO = PUESTO;
    }

    public int getID_EMPLEADO() {
        return ID_EMPLEADO;
    }

    public void setID_EMPLEADO(int ID_EMPLEADO) {
        this.ID_EMPLEADO = ID_EMPLEADO;
    }

    public int getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(int ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }

    public String getNOMBRES() {
        return NOMBRES;
    }

    public void setNOMBRES(String NOMBRES) {
        this.NOMBRES = NOMBRES;
    }

    public String getIDENTIFICACION() {
        return IDENTIFICACION;
    }

    public void setIDENTIFICACION(String IDENTIFICACION) {
        this.IDENTIFICACION = IDENTIFICACION;
    }

    public String getCORREO() {
        return CORREO;
    }

    public void setCORREO(String CORREO) {
        this.CORREO = CORREO;
    }

    public String getPUESTO() {
        return PUESTO;
    }

    public void setPUESTO(String PUESTO) {
        this.PUESTO = PUESTO;
    }
}
