package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class csAutenticar {

    private Connection con;
    private Statement stm;
    private ResultSet rs;

    public csAutenticar() {
        this.con = null;
        this.stm = null;
    }

    /*----------------------AUTENTICAR----------------------*/
    public Autenticar autenticarUsuario(String USUARIO, String CONTRASEÑA) {
        Autenticar a = null;
        //Instancia csConexion
        csConexion c1 = new csConexion();
        con = c1.conectar(); //Conectar DB
        rs = null;

        try 
        {
           stm = con.createStatement();
            rs = stm.executeQuery("SELECT U.ID_USUARIO, E.ID_EMPLEADO, U.USUARIO, E.NOMBRES "
                    + "FROM dbo.T_EMPLEADO E "
                    + "INNER JOIN dbo.T_USUARIO U "
                    + "ON U.ID_USUARIO = E.ID_EMPLEADO "
                    + "WHERE USUARIO = '" + USUARIO + "' AND CONTRASEÑA = '" + CONTRASEÑA + "'");
                     
            while (rs.next()) 

            {
                a = new Autenticar(rs.getInt(1), rs.getInt(1), rs.getString("USUARIO"), rs.getString("NOMBRES"));
            }

            c1.desconectar();//Desconectar DB
            con.close();
            stm.close();
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return null;
        }
        return a;
    }
}