package Modelo;

public class Software {

    private String TIPO_SOFTWARE;
    private int ID_SOFTWARE;

    /*-----CONSTRUCT-------*/
    public Software(String TIPO_SOFTWARE, int ID_SOFTWARE) {
        this.ID_SOFTWARE = ID_SOFTWARE;
        this.TIPO_SOFTWARE = TIPO_SOFTWARE;
    }


    /*-----GETTER & SETTER------*/
    public String getTIPO_SOFTWARE() {
        return TIPO_SOFTWARE;
    }

    public void setTIPO_SOFTWARE(String TIPO_SOFTWARE) {
        this.TIPO_SOFTWARE = TIPO_SOFTWARE;
    }

    public int getID_SOFTWARE() {
        return ID_SOFTWARE;
    }

    public void setID_SOFTWARE(int ID_SOFTWARE) {
        this.ID_SOFTWARE = ID_SOFTWARE;
    }
}
