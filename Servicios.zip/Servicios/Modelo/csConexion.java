package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class csConexion 
{  
    public String user, password;
    public String url, driver;
    public Connection cn;

    /*-----CONECTAR DB------*/
    public csConexion()
    {
        /*IMPORTANT*/
        this.user = "sa";
        this.password = "Dropdead+2022";
        this.url = "jdbc:sqlserver://localhost\\Help Desk Connection:1433;databaseName=HelpDesk"; //ALEJANDRO's IP 10.0.0.12
        this.driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        this.cn = null;
    }
    
    public Connection conectar()
    {
        try
        {
            Class.forName(this.driver);
            cn = DriverManager.getConnection(url, user, password);
            return cn;
        }
        catch (Exception ex)
        {   
            System.out.println(ex.toString());
            return null;
        }      
    }
    
    /*-----DESCONECTAR DB------*/
    public void desconectar() throws SQLException
    {
        cn.close();
    }  
}