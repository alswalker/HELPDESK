package wsServicios;

import Modelo.Autenticar;
import Modelo.csAutenticar;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvAutenticar")
public class srvAutenticar {

    /*-------METODO AUTENTICAR--------*/
    @WebMethod(operationName = "AutenticarUsuario")
    public Autenticar autenticarUsuario(@WebParam(name = "USUARIO") String USUARIO,
                                        @WebParam(name = "CONTRASEÑA") String CONTRASEÑA){
        csAutenticar a = new csAutenticar();
        return a.autenticarUsuario(USUARIO, CONTRASEÑA);
    }
}
