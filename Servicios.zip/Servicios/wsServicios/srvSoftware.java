package wsServicios;

import Modelo.Software;
import Modelo.csSoftware;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvSoftware")
public class srvSoftware {

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "InsertarSoftware")
    public int insertarSoftware(@WebParam(name = "TIPO_SOFTWARE") String TIPO_SOFTWARE) {
        csSoftware u = new csSoftware();
        return u.insertarSoftware(TIPO_SOFTWARE);
    }

    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "ActualizarSoftware")
    public int actualizarSoftware(@WebParam(name = "TIPO_SOFTWARE") String TIPO_SOFTWARE,
            @WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE) {
        csSoftware u = new csSoftware();
        return u.actualizarSoftware(TIPO_SOFTWARE, ID_SOFTWARE);
    }

    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "EliminarSoftware")
    public int eliminarSoftware(@WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE) {
        csSoftware u = new csSoftware();
        return u.eliminarSoftware(ID_SOFTWARE);
    }

    /*--------METODO LIST--------*/
    @WebMethod(operationName = "ListarSoftware")
    public ArrayList<Software> listarSoftware() {
        csSoftware u = new csSoftware();
        return u.listarSoftware();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarSoftwarePorID")
    public Software listarSoftwarePorID(@WebParam(name = "ID_SOFTWARE") int ID_SOFTWARE) {
        csSoftware u = new csSoftware();
        return u.listarSoftwarePorID(ID_SOFTWARE);
    }
}