package wsServicios;

import Modelo.Empresa;
import Modelo.csEmpresa;
import Modelo.csUsuario;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvEmpresa")
public class srvEmpresa {

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "InsertarEmpresa")
    public int insertarEmpresa(@WebParam(name = "NOMBRE_COMERCIAL") String NOMBRE_COMERCIAL,
            @WebParam(name = "NIT") String NIT,
            @WebParam(name = "DIRECCION") String DIRECCION,
            @WebParam(name = "TELEFONO") String TELEFONO,
            @WebParam(name = "CORREO") String CORREO) {
        csEmpresa e = new csEmpresa();
        return e.insertarEmpresa(NOMBRE_COMERCIAL, NIT, DIRECCION, TELEFONO, CORREO);
    }

    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "ActualizarEmpresa")
    public int actualizarEmpresa(@WebParam(name = "NOMBRE_COMERCIAL") String NOMBRE_COMERCIAL,
            @WebParam(name = "NIT") String NIT,
            @WebParam(name = "DIRECCION") String DIRECCION,
            @WebParam(name = "TELEFONO") String TELEFONO,
            @WebParam(name = "CORREO") String CORREO,
            @WebParam(name = "ID_EMPRESA") int ID_EMPRESA) {
        csEmpresa e = new csEmpresa();
        return e.actualizarEmpresa(NOMBRE_COMERCIAL, NIT, DIRECCION, TELEFONO, CORREO, ID_EMPRESA);
    }

    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "EliminarEmpresa")
    public int eliminarEmpresa(@WebParam(name = "ID_EMPRESA") int ID_EMPRESA) {
        csEmpresa u = new csEmpresa();
        return u.eliminarEmpresa(ID_EMPRESA);
    }

    /*--------METODO LIST--------*/
    @WebMethod(operationName = "ListarEmpresa")
    public ArrayList<Empresa> listarEmpresa() {
        csEmpresa e = new csEmpresa();
        return e.listarEmpresa();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarEmpresaPorID")
    public Empresa listarEmpresaPorID(@WebParam(name = "ID_EMPRESA") int ID_EMPRESA) {
        csEmpresa e = new csEmpresa();
        return e.listarEmpresaPorID(ID_EMPRESA);
    }
}
