package wsServicios;

import Modelo.Hardware;
import Modelo.csHardware;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvUsuario")
public class srvHardware {

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "InsertarHardware")
    public int insertarHardware(@WebParam(name = "TIPO_HARDWARE") String TIPO_HARDWARE) {
        csHardware u = new csHardware();
        return u.insertarHardware(TIPO_HARDWARE);
    }

    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "ActualizarHardware")
    public int actualizarHardware(@WebParam(name = "TIPO_HARDWARE") String TIPO_HARDWARE,
                                  @WebParam(name = "ID_HARDWARE") int ID_HARDWARE) {
        csHardware u = new csHardware();
        return u.actualizarHardware(TIPO_HARDWARE, ID_HARDWARE);
    }

    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "EliminarHardware")
    public int eliminarHardware(@WebParam(name = "ID_HARDWARE") int ID_HARDWARE) {
        csHardware u = new csHardware();
        return u.eliminarHardware(ID_HARDWARE);
    }

    /*--------METODO LIST--------*/
    @WebMethod(operationName = "ListarHardware")
    public ArrayList<Hardware> listarHardware() {
        csHardware u = new csHardware();
        return u.listarHardware();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarHardwarePorID")
    public Hardware listarHardwarePorID(@WebParam(name = "ID_HARDWARE") int ID_HARDWARE) {
        csHardware u = new csHardware();
        return u.listarHardwarePorID(ID_HARDWARE);
    }
}
