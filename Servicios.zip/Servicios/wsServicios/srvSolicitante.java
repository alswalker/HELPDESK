package wsServicios;

import Modelo.Solicitante;
import Modelo.csSolicitante;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "srvSolicitante")
public class srvSolicitante {

    /*-------METODO INSERT--------*/
    @WebMethod(operationName = "InsertarSolicitante")
    public int insertarSolicitante(@WebParam(name = "ID_USUARIO") int ID_USUARIO,
            @WebParam(name = "ID_EMPRESA") int ID_EMPRESA,
            @WebParam(name = "NOMBRES") String NOMBRES,
            @WebParam(name = "IDENTIFICACION") String IDENTIFICACION,
            @WebParam(name = "CORREO") String CORREO) {
        csSolicitante u = new csSolicitante();
        return u.insertarSolicitante(NOMBRES, IDENTIFICACION, CORREO, ID_USUARIO, ID_EMPRESA);
    }

    /*-------METODO UPDATE--------*/
    @WebMethod(operationName = "ActualizarSolicitante")
    public int actualizarSolicitante(@WebParam(name = "ID_USUARIO") int ID_USUARIO,
            @WebParam(name = "ID_EMPRESA") int ID_EMPRESA,
            @WebParam(name = "NOMBRES") String NOMBRES,
            @WebParam(name = "IDENTIFICACION") String IDENTIFICACION,
            @WebParam(name = "CORREO") String CORREO,
            @WebParam(name = "ID_SOLICITANTE") int ID_SOLICITANTE) {
        csSolicitante u = new csSolicitante();
        return u.actualizarSolicitante(ID_SOLICITANTE, ID_USUARIO, ID_EMPRESA, NOMBRES, IDENTIFICACION, CORREO);
    }

    /*-------METODO DELETE--------*/
    @WebMethod(operationName = "EliminarSolicitante")
    public int eliminarSolicitante(@WebParam(name = "ID_EMPRESA") int ID_EMPRESA) {
        csSolicitante u = new csSolicitante();
        return u.eliminarSolicitante(ID_EMPRESA);
    }

    /*--------METODO LIST--------*/
    @WebMethod(operationName = "ListarSolicitante")
    public ArrayList<Solicitante> listarSolicitante() {
        csSolicitante u = new csSolicitante();
        return u.listarSolicitante();
    }

    /*-----METODO LIST BY ID------*/
    @WebMethod(operationName = "ListarSolicitantePorID")
    public Solicitante listarSolicitantePorID(@WebParam(name = "ID_SOLICITANTE") int ID_SOLICITANTE) {
        csSolicitante u = new csSolicitante();
        return u.listarSolicitantePorID(ID_SOLICITANTE);
    }
}
